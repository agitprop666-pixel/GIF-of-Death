from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

from PIL import Image

# --- PyQt6 Imports ---
from PyQt6.QtCore import Qt, pyqtSignal, QThread
from PyQt6.QtGui import QColor, QFont, QPainter, QPixmap, QImage, QPen, QIcon
from PyQt6.QtWidgets import (
    QApplication, QWidget, QSplashScreen, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QSlider, QSpinBox, QDoubleSpinBox, QFileDialog,
    QTabWidget, QProgressBar, QCheckBox, QComboBox, QGroupBox, QScrollArea,
    QMessageBox, QGroupBox, QFormLayout
)

# --- Global Definitions ---
APP_NAME = "GIF of Death"
ORG_NAME = "Death's Head Software"
WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 800

# =============================================================================
# Utility Functions
# =============================================================================

def resource_path(relative_path: str) -> str:
    """
    Return the absolute path to a resource, handling both development and
    PyInstaller bundled contexts.
    """
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), relative_path)

def create_splash():
    """
    Creates the QSplashScreen using the skull image.
    Falls back to generated skull art if image not found.
    """
    try:
        # Try to load splash.png from the same directory
        splash_path = Path(__file__).parent / "splash.png"
        
        if not splash_path.exists():
            # Try resource_path for packaged builds
            splash_path = Path(resource_path("splash.png"))
        
        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if not pixmap.isNull():
                # Scale to 800x600 while maintaining aspect ratio
                if pixmap.width() != 800 or pixmap.height() != 600:
                    pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                          Qt.TransformationMode.SmoothTransformation)
                
                painter = QPainter(pixmap)
                painter.setPen(QColor(255, 255, 255))
                
                # App name at top
                painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
                text_rect = pixmap.rect()
                text_rect.setTop(40)
                text_rect.setBottom(100)
                painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
                
                # Org name at bottom
                painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
                footer_rect = pixmap.rect()
                footer_rect.setTop(pixmap.height() - 100)
                footer_rect.setBottom(pixmap.height() - 50)
                painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
                
                painter.end()
                return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
        
        # Fallback: generate dark screen with text
        pixmap = QPixmap(800, 600)
        pixmap.fill(QColor(20, 20, 20))
        painter = QPainter(pixmap)
        painter.setPen(QColor(255, 255, 255))
        
        painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
        text_rect = pixmap.rect()
        text_rect.setTop(40)
        text_rect.setBottom(100)
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
        
        painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
        footer_rect = pixmap.rect()
        footer_rect.setTop(pixmap.height() - 50)
        footer_rect.setBottom(pixmap.height())
        painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
        
        painter.end()
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    
    except Exception as e:
        print(f"Splash error: {e}")
        return None

# =============================================================================
# Worker Threads
# =============================================================================

class VideoToGifWorker(QThread):
    """Worker thread for converting video to GIF."""
    progress = pyqtSignal(int)
    finished = pyqtSignal(str)
    error    = pyqtSignal(str)

    def __init__(self, video_path: str, output_path: str, fps: int, quality: int,
                 scale: int):
        super().__init__()
        self.video_path  = video_path
        self.output_path = output_path
        self.fps         = fps
        self.quality     = quality
        self.scale       = scale

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _run(cmd):
        """Run a subprocess with no visible console on Windows."""
        kwargs = {}
        if sys.platform == 'win32':
            kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
        return subprocess.run(cmd, capture_output=True, **kwargs)

    @staticmethod
    def _check(cmd):
        """Run and raise on non-zero exit; no console on Windows."""
        kwargs = {'check': True, 'capture_output': True}
        if sys.platform == 'win32':
            kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
        return subprocess.run(cmd, **kwargs)

    @staticmethod
    def _last_error_lines(stderr_bytes, n=6):
        """Extract the last n non-empty lines from ffmpeg stderr."""
        lines = [l.strip() for l in stderr_bytes.decode(errors='replace').splitlines()
                 if l.strip()]
        return '\n'.join(lines[-n:]) if lines else '(no output)'

    # ------------------------------------------------------------------

    def run(self):
        temp_frames = None
        try:
            self.progress.emit(5)

            # ── Extract frames ─────────────────────────────────────────
            temp_frames = os.path.join(
                os.path.dirname(self.output_path),
                '_gif_tmp_' + os.path.basename(self.output_path).replace('.gif', '')
            )
            os.makedirs(temp_frames, exist_ok=True)

            vf = f"fps={self.fps}"
            if self.scale:
                vf += f",scale={self.scale}:-2"

            frame_pattern = os.path.join(temp_frames, 'frame_%04d.png')
            extract = self._run([
                'ffmpeg', '-y',
                '-i',  self.video_path,
                '-vf', vf,
                frame_pattern
            ])
            if extract.returncode != 0:
                self.error.emit("FFmpeg frame extraction failed:\n"
                                + self._last_error_lines(extract.stderr))
                return

            self.progress.emit(40)

            # ── 3. Build GIF with Pillow ───────────────────────────────
            frame_files = sorted(
                f for f in os.listdir(temp_frames) if f.endswith('.png')
            )
            if not frame_files:
                self.error.emit("FFmpeg produced no frames — check trim range.")
                return

            frame_ms = int(1000 / self.fps)
            images   = []

            for i, name in enumerate(frame_files):
                img = Image.open(os.path.join(temp_frames, name)).convert('RGB')
                if self.quality < 256:
                    img = img.quantize(colors=self.quality, dither=Image.Dither.FLOYDSTEINBERG)
                images.append(img)
                self.progress.emit(40 + int(i / len(frame_files) * 55))

            images[0].save(
                self.output_path,
                save_all=True,
                append_images=images[1:],
                duration=frame_ms,
                loop=0,
                optimize=False,
            )

            self.progress.emit(100)
            self.finished.emit(self.output_path)

        except Exception as e:
            self.error.emit(str(e))
        finally:
            if temp_frames:
                shutil.rmtree(temp_frames, ignore_errors=True)

class GifEditWorker(QThread):
    """Worker thread for editing GIF (trim, speed, crop)."""
    progress = pyqtSignal(int)
    finished = pyqtSignal(str)
    error = pyqtSignal(str)

    def __init__(self, gif_path: str, output_path: str,
                 crop_box: tuple = None, fps_override: int = None):
        super().__init__()
        self.gif_path     = gif_path
        self.output_path  = output_path
        self.crop_box     = crop_box
        self.fps_override = fps_override

    def run(self):
        try:
            gif = Image.open(self.gif_path)
            frames = []
            durations = []

            try:
                while True:
                    frames.append(gif.convert('RGB'))
                    durations.append(gif.info.get('duration', 100))
                    gif.seek(gif.tell() + 1)
            except EOFError:
                pass

            self.progress.emit(20)

            if not frames:
                self.error.emit("Could not read GIF frames")
                return

            self.progress.emit(40)

            # Apply frame rate override
            if self.fps_override is not None:
                frame_ms  = int(1000 / self.fps_override)
                durations = [frame_ms] * len(durations)

            # Crop
            if self.crop_box:
                x1, y1, x2, y2 = self.crop_box
                frames = [f.crop((x1, y1, x2, y2)) for f in frames]

            self.progress.emit(80)

            if frames:
                frames[0].save(
                    self.output_path,
                    save_all=True,
                    append_images=frames[1:],
                    duration=durations,
                    loop=0,
                    optimize=False,
                )

            self.progress.emit(100)
            self.finished.emit(self.output_path)

        except Exception as e:
            self.error.emit(f"Error: {str(e)}")

class GifLoadWorker(QThread):
    """
    Loads a GIF's frames in a background thread so the UI never freezes.
    Emits progress (0-100) and finished(frames, durations) on completion.
    """
    progress = pyqtSignal(int)
    finished = pyqtSignal(list, list)   # frames (PIL), durations (ms)
    error    = pyqtSignal(str)

    def __init__(self, gif_path: str):
        super().__init__()
        self.gif_path = gif_path

    def run(self):
        try:
            gif = Image.open(self.gif_path)

            # --- first pass: count frames so we can report progress ---
            n = 0
            try:
                while True:
                    n += 1
                    gif.seek(gif.tell() + 1)
            except EOFError:
                pass

            if n == 0:
                self.error.emit("No frames found in GIF")
                return

            # --- second pass: extract frames ---
            gif.seek(0)
            frames    = []
            durations = []
            try:
                while True:
                    frames.append(gif.convert('RGB'))
                    durations.append(gif.info.get('duration', 100))
                    self.progress.emit(int(len(frames) / n * 100))
                    gif.seek(gif.tell() + 1)
            except EOFError:
                pass

            self.finished.emit(frames, durations)

        except Exception as e:
            self.error.emit(str(e))

# =============================================================================
# UI Components
# =============================================================================

class VideoToGifTab(QWidget):
    """Tab for converting video to GIF."""
    
    def __init__(self):
        super().__init__()
        self.video_path = None
        self.worker = None
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # File selection
        file_layout = QHBoxLayout()
        self.file_label = QLabel("No video selected")
        self.file_label.setStyleSheet("color: #888; padding: 10px;")
        file_btn = QPushButton("Select Video")
        file_btn.clicked.connect(self.select_video)
        file_layout.addWidget(self.file_label)
        file_layout.addWidget(file_btn)
        layout.addLayout(file_layout)
        
        # Preview
        preview_group = QGroupBox("Preview")
        preview_layout = QVBoxLayout()
        self.preview_label = QLabel("No preview")
        self.preview_label.setMinimumHeight(250)
        self.preview_label.setStyleSheet("background-color: #1a1a1a; border: 1px solid #333;")
        self.preview_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        preview_layout.addWidget(self.preview_label)
        preview_group.setLayout(preview_layout)
        layout.addWidget(preview_group)
        
        # Settings
        settings_group = QGroupBox("Conversion Settings")
        settings_layout = QFormLayout()

        # FPS
        fps_layout = QHBoxLayout()
        self.fps_combo = QComboBox()
        self.fps_combo.addItems(["5 fps", "10 fps", "15 fps", "20 fps", "24 fps", "30 fps"])
        self.fps_values = [5, 10, 15, 20, 24, 30]
        self.fps_combo.setCurrentIndex(2)   # 15 fps default
        fps_layout.addWidget(self.fps_combo)
        fps_layout.addStretch()
        settings_layout.addRow("Frame Rate:", fps_layout)

        # Quality
        quality_layout = QHBoxLayout()
        self.quality_slider = QSlider(Qt.Orientation.Horizontal)
        self.quality_slider.setMinimum(8)
        self.quality_slider.setMaximum(256)
        self.quality_slider.setValue(128)
        self.quality_slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.quality_label = QLabel("128 colors")
        self.quality_slider.sliderMoved.connect(self.update_quality_label)
        self.quality_slider.valueChanged.connect(self.update_quality_label)
        quality_layout.addWidget(self.quality_slider)
        quality_layout.addWidget(self.quality_label)
        settings_layout.addRow("Color Depth:", quality_layout)
        
        # Scale
        scale_layout = QHBoxLayout()
        self.scale_combo = QComboBox()
        self.scale_combo.addItems(["No scaling", "320px", "480px", "640px", "800px", "1280px"])
        self.scale_values = [0, 320, 480, 640, 800, 1280]
        self.scale_combo.setCurrentIndex(3)
        scale_layout.addWidget(self.scale_combo)
        scale_layout.addStretch()
        settings_layout.addRow("Scale:", scale_layout)
        
        settings_group.setLayout(settings_layout)
        layout.addWidget(settings_group)
        
        # Progress
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Convert button
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        self.convert_btn = QPushButton("Convert to GIF")
        self.convert_btn.setMinimumWidth(150)
        self.convert_btn.setStyleSheet(
            "QPushButton { background-color: #2a2a2a; color: #fff; padding: 8px; border: 1px solid #555; }"
            "QPushButton:hover { background-color: #3a3a3a; }"
        )
        self.convert_btn.clicked.connect(self.convert_video)
        btn_layout.addWidget(self.convert_btn)
        layout.addLayout(btn_layout)
        
        layout.addStretch()
        self.setLayout(layout)
    
    def select_video(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Video", "",
            "Video Files (*.mp4 *.avi *.mov *.mkv *.flv *.wmv);;All Files (*)"
        )
        if path:
            self.video_path = path
            self.file_label.setText(f"File: {Path(path).name}")
            self.file_label.setStyleSheet("color: #fff; padding: 10px;")
            self.generate_preview()
    
    def generate_preview(self):
        """Generate a preview thumbnail from the first frame."""
        if not self.video_path:
            return
        try:
            cmd = [
                'ffmpeg', '-i', self.video_path,
                '-ss', '0', '-vframes', '1',
                '-vf', 'scale=300:-2',
                '-f', 'image2pipe', '-c:v', 'png', '-'
            ]
            kwargs = {'capture_output': True}
            if sys.platform == 'win32':
                kwargs['creationflags'] = subprocess.CREATE_NO_WINDOW
            result = subprocess.run(cmd, **kwargs)
            if result.returncode == 0 and result.stdout:
                pixmap = QPixmap()
                pixmap.loadFromData(result.stdout)
                if not pixmap.isNull():
                    scaled = pixmap.scaledToHeight(250, Qt.TransformationMode.SmoothTransformation)
                    self.preview_label.setPixmap(scaled)
                    return
            self.preview_label.setText("Preview unavailable")
        except Exception as e:
            self.preview_label.setText(f"Preview error: {str(e)}")
    
    def update_quality_label(self):
        quality = self.quality_slider.value()
        self.quality_label.setText(f"{quality} colors")

    def convert_video(self):
        if not self.video_path:
            QMessageBox.warning(self, "Error", "Please select a video file first")
            return

        output_path, _ = QFileDialog.getSaveFileName(
            self, "Save GIF As", "",
            "GIF Files (*.gif);;All Files (*)"
        )
        if not output_path:
            return
        if not output_path.lower().endswith('.gif'):
            output_path += '.gif'

        fps        = self.fps_values[self.fps_combo.currentIndex()]
        quality    = self.quality_slider.value()
        scale      = self.scale_values[self.scale_combo.currentIndex()]

        self.worker = VideoToGifWorker(
            self.video_path, output_path, fps, quality, scale
        )
        self.worker.progress.connect(self.on_progress)
        self.worker.finished.connect(self.on_finished)
        self.worker.error.connect(self.on_error)

        self.convert_btn.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.worker.start()
    
    def on_progress(self, value):
        self.progress_bar.setValue(value)
    
    def on_finished(self, path):
        self.convert_btn.setEnabled(True)
        self.progress_bar.setVisible(False)
        QMessageBox.information(self, "Success", f"GIF saved: {Path(path).name}")
    
    def on_error(self, msg):
        self.convert_btn.setEnabled(True)
        self.progress_bar.setVisible(False)
        QMessageBox.critical(self, "Error", msg)

class CropPreviewLabel(QLabel):
    """Custom label for interactive crop box editing with handles."""

    crop_changed = pyqtSignal(int, int, int, int)   # x, y, w, h in original frame coords

    HANDLE_SIZE = 8
    MIN_CROP    = 10   # minimum crop dimension in original-frame pixels

    def __init__(self):
        super().__init__()
        self.original_pixmap = None
        self.scale_factor    = 1.0    # original_pixels_per_display_pixel
        self.frame_w         = 640    # original frame width
        self.frame_h         = 480    # original frame height

        # Crop box in ORIGINAL frame coordinates
        self.crop_x = 0
        self.crop_y = 0
        self.crop_w = 640
        self.crop_h = 480

        # Drag state
        self.dragging        = None
        self.drag_start_x    = 0
        self.drag_start_y    = 0
        self.drag_start_crop = (0, 0, 0, 0)

        self.setMouseTracking(True)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load_frame(self, pixmap, frame, reset_crop=False):
        """
        Supply a new displayed pixmap plus the original frame for scaling.
        reset_crop=True only when a new GIF is first opened.
        """
        self.original_pixmap = pixmap
        self.frame_w = frame.width
        self.frame_h = frame.height

        if pixmap.height() > 0:
            self.scale_factor = frame.height / pixmap.height()

        if reset_crop:
            # Inset to 80 % so the shadow overlay is immediately visible
            # and the user has clear handles to grab from the start.
            margin_x = self.frame_w // 10
            margin_y = self.frame_h // 10
            self.crop_x = margin_x
            self.crop_y = margin_y
            self.crop_w = self.frame_w - 2 * margin_x
            self.crop_h = self.frame_h - 2 * margin_y

        self._draw()

    def set_crop(self, x, y, w, h):
        """Update crop from spinboxes; clamps to frame bounds."""
        self.crop_x, self.crop_y, self.crop_w, self.crop_h = \
            self._clamp_crop(x, y, w, h)
        self._draw()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _clamp_crop(self, x, y, w, h):
        """Clamp a crop rect so it stays inside the frame with MIN_CROP size."""
        w = max(self.MIN_CROP, w)
        h = max(self.MIN_CROP, h)
        x = max(0, min(x, self.frame_w - w))
        y = max(0, min(y, self.frame_h - h))
        w = min(w, self.frame_w - x)
        h = min(h, self.frame_h - y)
        return x, y, w, h

    def _to_disp(self):
        """Return crop box in display-pixel coordinates (all guaranteed ≥ 0)."""
        if not self.original_pixmap:
            return 0, 0, 0, 0
        sf  = self.scale_factor
        dx  = max(0, int(self.crop_x / sf))
        dy  = max(0, int(self.crop_y / sf))
        dx2 = min(self.original_pixmap.width(),  int((self.crop_x + self.crop_w) / sf))
        dy2 = min(self.original_pixmap.height(), int((self.crop_y + self.crop_h) / sf))
        return dx, dy, max(0, dx2 - dx), max(0, dy2 - dy)

    def _draw(self):
        """Repaint the pixmap with the crop overlay. Never passes negative sizes to Qt."""
        if not self.original_pixmap:
            return

        pm = self.original_pixmap.copy()
        pw, ph = pm.width(), pm.height()
        dx, dy, dw, dh = self._to_disp()

        painter = QPainter(pm)

        shadow = QColor(0, 0, 0, 150)
        # Top strip
        if dy > 0:
            painter.fillRect(0, 0, pw, dy, shadow)
        # Bottom strip
        if dy + dh < ph:
            painter.fillRect(0, dy + dh, pw, ph - (dy + dh), shadow)
        # Left strip
        if dx > 0:
            painter.fillRect(0, dy, dx, dh, shadow)
        # Right strip
        if dx + dw < pw:
            painter.fillRect(dx + dw, dy, pw - (dx + dw), dh, shadow)

        # Crop border
        pen = QPen(QColor(0, 255, 0))
        pen.setWidth(2)
        painter.setPen(pen)
        painter.drawRect(dx, dy, dw, dh)

        # Handles — drawn last so they sit on top; clipped to pixmap rect automatically
        hs = self.HANDLE_SIZE
        hc = QColor(0, 255, 0)
        cx, cy = dx + dw // 2, dy + dh // 2
        for hx, hy in [
            (dx,      dy),       # NW
            (dx + dw, dy),       # NE
            (dx,      dy + dh),  # SW
            (dx + dw, dy + dh),  # SE
            (cx,      dy),       # N
            (cx,      dy + dh),  # S
            (dx,      cy),       # W
            (dx + dw, cy),       # E
        ]:
            painter.fillRect(hx - hs // 2, hy - hs // 2, hs, hs, hc)

        painter.end()
        self.setPixmap(pm)

    def _handle_at(self, px, py):
        """Return handle name at display position, or None."""
        dx, dy, dw, dh = self._to_disp()
        cx, cy = dx + dw // 2, dy + dh // 2
        threshold = self.HANDLE_SIZE + 2

        handles = {
            'nw': (dx,      dy),
            'ne': (dx + dw, dy),
            'sw': (dx,      dy + dh),
            'se': (dx + dw, dy + dh),
            'n':  (cx,      dy),
            's':  (cx,      dy + dh),
            'w':  (dx,      cy),
            'e':  (dx + dw, cy),
        }
        for name, (hx, hy) in handles.items():
            if abs(px - hx) < threshold and abs(py - hy) < threshold:
                return name

        if dx <= px <= dx + dw and dy <= py <= dy + dh:
            return 'move'
        return None

    def _label_to_pixmap(self, lx, ly):
        """
        Convert a label-space coordinate (from a mouse event) to
        pixmap-space.  Because the label uses AlignCenter the pixmap
        is offset by up to (label_w - pixmap_w) / 2 in each axis.
        """
        if not self.original_pixmap:
            return lx, ly
        ox = max(0, (self.width()  - self.original_pixmap.width())  // 2)
        oy = max(0, (self.height() - self.original_pixmap.height()) // 2)
        return lx - ox, ly - oy

    # ------------------------------------------------------------------
    # Mouse events
    # ------------------------------------------------------------------

    def mousePressEvent(self, event):
        if not self.original_pixmap:
            return
        # Convert from label space → pixmap space before any hit-testing
        px, py = self._label_to_pixmap(int(event.position().x()),
                                        int(event.position().y()))
        handle = self._handle_at(px, py)
        if handle:
            self.dragging        = handle
            self.drag_start_x    = px   # stored in pixmap space
            self.drag_start_y    = py
            self.drag_start_crop = (self.crop_x, self.crop_y,
                                    self.crop_w, self.crop_h)

    def mouseMoveEvent(self, event):
        if not self.original_pixmap:
            return
        # All coordinates in pixmap space from here on
        px, py = self._label_to_pixmap(int(event.position().x()),
                                        int(event.position().y()))

        # Cursor update when not dragging
        if not self.dragging:
            cursor_map = {
                'nw': Qt.CursorShape.SizeFDiagCursor,
                'ne': Qt.CursorShape.SizeBDiagCursor,
                'sw': Qt.CursorShape.SizeBDiagCursor,
                'se': Qt.CursorShape.SizeFDiagCursor,
                'n':  Qt.CursorShape.SizeVerCursor,
                's':  Qt.CursorShape.SizeVerCursor,
                'w':  Qt.CursorShape.SizeHorCursor,
                'e':  Qt.CursorShape.SizeHorCursor,
                'move': Qt.CursorShape.OpenHandCursor,
            }
            h = self._handle_at(px, py)
            self.setCursor(cursor_map.get(h, Qt.CursorShape.ArrowCursor))
            return

        # drag_start_x/y are already in pixmap space, so delta is consistent
        sf  = self.scale_factor
        dx  = int((px - self.drag_start_x) * sf)
        dy  = int((py - self.drag_start_y) * sf)
        ox, oy, ow, oh = self.drag_start_crop

        x, y, w, h = ox, oy, ow, oh
        d = self.dragging
        if d == 'move':
            x, y = ox + dx, oy + dy
        elif d == 'nw':
            x, y, w, h = ox + dx, oy + dy, ow - dx, oh - dy
        elif d == 'ne':
            y, w, h    = oy + dy, ow + dx, oh - dy
        elif d == 'sw':
            x, w, h    = ox + dx, ow - dx, oh + dy
        elif d == 'se':
            w, h       = ow + dx, oh + dy
        elif d == 'n':
            y, h       = oy + dy, oh - dy
        elif d == 's':
            h          = oh + dy
        elif d == 'w':
            x, w       = ox + dx, ow - dx
        elif d == 'e':
            w          = ow + dx

        self.crop_x, self.crop_y, self.crop_w, self.crop_h = \
            self._clamp_crop(x, y, w, h)

        self.crop_changed.emit(self.crop_x, self.crop_y,
                               self.crop_w, self.crop_h)
        self._draw()

    def mouseReleaseEvent(self, event):
        self.dragging = None

class GifEditTab(QWidget):
    """Tab for editing GIF (trim, speed, crop)."""
    
    def __init__(self):
        super().__init__()
        self.gif_path      = None
        self.frames        = []
        self.durations     = []
        self.current_frame = 0
        self.worker        = None   # export worker
        self.load_worker   = None   # GifLoadWorker
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # File selection
        file_layout = QHBoxLayout()
        self.file_label = QLabel("No GIF selected")
        self.file_label.setStyleSheet("color: #888; padding: 10px;")
        self.select_btn = QPushButton("Select GIF")
        self.select_btn.clicked.connect(self.select_gif)
        file_layout.addWidget(self.file_label)
        file_layout.addWidget(self.select_btn)
        layout.addLayout(file_layout)

        # Loading progress bar (hidden until a GIF is loading)
        self.load_progress = QProgressBar()
        self.load_progress.setVisible(False)
        self.load_progress.setFormat("Loading… %p%")
        layout.addWidget(self.load_progress)
        
        # Preview
        preview_group = QGroupBox("Preview (drag to crop)")
        preview_layout = QVBoxLayout()
        self.preview_label = CropPreviewLabel()
        self.preview_label.setText("No preview")
        self.preview_label.setMinimumHeight(250)
        self.preview_label.setStyleSheet("background-color: #1a1a1a; border: 1px solid #333;")
        self.preview_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_label.crop_changed.connect(self.on_crop_changed)
        preview_layout.addWidget(self.preview_label)
        
        # Frame navigation
        nav_layout = QHBoxLayout()
        self.frame_spin = QSpinBox()
        self.frame_spin.setMinimum(0)
        self.frame_spin.valueChanged.connect(self.show_frame)
        self.frame_label = QLabel("/ 0")
        nav_layout.addWidget(QLabel("Frame:"))
        nav_layout.addWidget(self.frame_spin)
        nav_layout.addWidget(self.frame_label)
        nav_layout.addStretch()
        preview_layout.addLayout(nav_layout)
        
        preview_group.setLayout(preview_layout)
        layout.addWidget(preview_group)
        
        # Edit settings
        settings_group = QGroupBox("Edit Settings")
        settings_layout = QFormLayout()

        # Speed
        # Frame rate override
        fps_layout = QHBoxLayout()
        self.edit_fps_combo = QComboBox()
        self.edit_fps_combo.addItems(["Original", "5 fps", "10 fps", "15 fps", "20 fps", "24 fps", "30 fps"])
        self.edit_fps_values = [None, 5, 10, 15, 20, 24, 30]
        self.edit_fps_combo.setCurrentIndex(0)
        fps_layout.addWidget(self.edit_fps_combo)
        fps_layout.addStretch()
        settings_layout.addRow("Frame Rate:", fps_layout)
        
        # Crop
        crop_label = QLabel("Crop (pixels)")
        crop_label.setStyleSheet("font-weight: bold; margin-top: 10px;")
        settings_layout.addRow(crop_label)
        
        crop_x_layout = QHBoxLayout()
        self.crop_x_spin = QSpinBox()
        self.crop_x_spin.setMinimum(0)
        self.crop_x_spin.setMaximum(5000)
        self.crop_x_spin.setValue(0)
        self.crop_x_spin.setSuffix(" px")
        self.crop_x_spin.valueChanged.connect(self.update_crop_preview)
        crop_x_layout.addWidget(QLabel("X:"))
        crop_x_layout.addWidget(self.crop_x_spin)
        settings_layout.addRow(crop_x_layout)
        
        crop_y_layout = QHBoxLayout()
        self.crop_y_spin = QSpinBox()
        self.crop_y_spin.setMinimum(0)
        self.crop_y_spin.setMaximum(5000)
        self.crop_y_spin.setValue(0)
        self.crop_y_spin.setSuffix(" px")
        self.crop_y_spin.valueChanged.connect(self.update_crop_preview)
        crop_y_layout.addWidget(QLabel("Y:"))
        crop_y_layout.addWidget(self.crop_y_spin)
        settings_layout.addRow(crop_y_layout)
        
        crop_w_layout = QHBoxLayout()
        self.crop_w_spin = QSpinBox()
        self.crop_w_spin.setMinimum(1)
        self.crop_w_spin.setMaximum(5000)
        self.crop_w_spin.setValue(640)
        self.crop_w_spin.setSuffix(" px")
        self.crop_w_spin.valueChanged.connect(self.update_crop_preview)
        crop_w_layout.addWidget(QLabel("Width:"))
        crop_w_layout.addWidget(self.crop_w_spin)
        settings_layout.addRow(crop_w_layout)
        
        crop_h_layout = QHBoxLayout()
        self.crop_h_spin = QSpinBox()
        self.crop_h_spin.setMinimum(1)
        self.crop_h_spin.setMaximum(5000)
        self.crop_h_spin.setValue(480)
        self.crop_h_spin.setSuffix(" px")
        self.crop_h_spin.valueChanged.connect(self.update_crop_preview)
        crop_h_layout.addWidget(QLabel("Height:"))
        crop_h_layout.addWidget(self.crop_h_spin)
        settings_layout.addRow(crop_h_layout)
        
        reset_crop_btn = QPushButton("Reset Crop")
        reset_crop_btn.setMaximumWidth(100)
        reset_crop_btn.clicked.connect(self.reset_crop)
        settings_layout.addRow(reset_crop_btn)
        
        settings_group.setLayout(settings_layout)
        layout.addWidget(settings_group)
        
        # Progress
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Export button
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        self.export_btn = QPushButton("Export GIF")
        self.export_btn.setMinimumWidth(150)
        self.export_btn.setStyleSheet(
            "QPushButton { background-color: #2a2a2a; color: #fff; padding: 8px; border: 1px solid #555; }"
            "QPushButton:hover { background-color: #3a3a3a; }"
        )
        self.export_btn.clicked.connect(self.export_gif)
        btn_layout.addWidget(self.export_btn)
        layout.addLayout(btn_layout)
        
        layout.addStretch()
        self.setLayout(layout)
    
    def select_gif(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select GIF", "",
            "GIF Files (*.gif);;All Files (*)"
        )
        if path:
            self.gif_path = path
            self.file_label.setText(f"File: {Path(path).name}")
            self.file_label.setStyleSheet("color: #fff; padding: 10px;")
            self.load_gif()

    def _frame_to_scaled_pixmap(self, frame):
        """
        Safely convert a PIL frame to a scaled QPixmap.
        .copy() forces QImage to own its pixel buffer rather than
        holding a raw pointer into the Python bytes object.
        """
        img_data = frame.tobytes()
        q_img = QImage(img_data, frame.width, frame.height,
                       frame.width * 3, QImage.Format.Format_RGB888).copy()
        return QPixmap.fromImage(q_img).scaledToHeight(
            250, Qt.TransformationMode.SmoothTransformation)

    def load_gif(self):
        """Kick off background GIF loading — never runs PIL on the main thread."""
        if not self.gif_path:
            return

        # Disable UI while loading
        self.select_btn.setEnabled(False)
        self.load_progress.setValue(0)
        self.load_progress.setVisible(True)
        self.frames    = []
        self.durations = []

        self.load_worker = GifLoadWorker(self.gif_path)
        self.load_worker.progress.connect(self.load_progress.setValue)
        self.load_worker.finished.connect(self.on_gif_loaded)
        self.load_worker.error.connect(self.on_gif_load_error)
        self.load_worker.start()

    def on_gif_loaded(self, frames, durations):
        """Called on the main thread once GifLoadWorker has finished."""
        self.load_progress.setVisible(False)
        self.select_btn.setEnabled(True)

        self.frames    = frames
        self.durations = durations

        if not self.frames:
            QMessageBox.warning(self, "Warning", "No frames found in GIF")
            return

        total = len(self.frames)
        first = self.frames[0]

        # Block every signal-emitting widget so setMaximum/setValue
        # calls don't cascade into show_frame or update_crop_preview
        # while state is still being set up.
        _widgets = [self.frame_spin,
                    self.crop_x_spin, self.crop_y_spin,
                    self.crop_w_spin,  self.crop_h_spin]
        for w in _widgets:
            w.blockSignals(True)

        self.frame_spin.setMaximum(total - 1)
        self.frame_spin.setValue(0)
        self.frame_label.setText(f"/ {total - 1}")
        self.crop_x_spin.setMaximum(first.width)
        self.crop_y_spin.setMaximum(first.height)
        self.crop_w_spin.setMaximum(first.width)
        self.crop_h_spin.setMaximum(first.height)
        self.crop_x_spin.setValue(0)
        self.crop_y_spin.setValue(0)
        self.crop_w_spin.setValue(first.width)
        self.crop_h_spin.setValue(first.height)

        for w in _widgets:
            w.blockSignals(False)

        # Single deliberate draw — no signal chain, no redundant calls
        self.current_frame = 0
        self.preview_label.load_frame(
            self._frame_to_scaled_pixmap(first), first, reset_crop=True)

    def on_gif_load_error(self, msg):
        """Called on the main thread if GifLoadWorker fails."""
        self.load_progress.setVisible(False)
        self.select_btn.setEnabled(True)
        QMessageBox.critical(self, "Error", f"Could not load GIF: {msg}")

    def show_frame(self, index):
        """Display a specific frame (called by frame_spin valueChanged)."""
        if 0 <= index < len(self.frames):
            self.current_frame = index
            frame = self.frames[index]
            self.preview_label.load_frame(
                self._frame_to_scaled_pixmap(frame), frame, reset_crop=False)
    
    def on_crop_changed(self, x, y, w, h):
        """Handle crop box changes from the preview label."""
        # Block signals to prevent feedback loops
        self.crop_x_spin.blockSignals(True)
        self.crop_y_spin.blockSignals(True)
        self.crop_w_spin.blockSignals(True)
        self.crop_h_spin.blockSignals(True)
        
        self.crop_x_spin.setValue(x)
        self.crop_y_spin.setValue(y)
        self.crop_w_spin.setValue(w)
        self.crop_h_spin.setValue(h)
        
        self.crop_x_spin.blockSignals(False)
        self.crop_y_spin.blockSignals(False)
        self.crop_w_spin.blockSignals(False)
        self.crop_h_spin.blockSignals(False)
    
    def update_crop_preview(self):
        """Sync spinbox values into the interactive crop label."""
        self.preview_label.set_crop(
            self.crop_x_spin.value(), self.crop_y_spin.value(),
            self.crop_w_spin.value(), self.crop_h_spin.value()
        )

    def reset_crop(self):
        """Reset crop to the full frame."""
        if self.frames:
            frame = self.frames[0]
            self.preview_label.set_crop(0, 0, frame.width, frame.height)
            # Sync spinboxes without triggering a redraw loop
            for spin, val in [(self.crop_x_spin, 0), (self.crop_y_spin, 0),
                              (self.crop_w_spin, frame.width),
                              (self.crop_h_spin, frame.height)]:
                spin.blockSignals(True)
                spin.setValue(val)
                spin.blockSignals(False)
    
    def export_gif(self):
        if not self.gif_path or not self.frames:
            QMessageBox.warning(self, "Error", "Please select and load a GIF first")
            return
        
        output_path, _ = QFileDialog.getSaveFileName(
            self, "Export GIF As", "",
            "GIF Files (*.gif);;All Files (*)"
        )
        
        if not output_path:
            return
        
        if not output_path.lower().endswith('.gif'):
            output_path += '.gif'
        
        fps_override = self.edit_fps_values[self.edit_fps_combo.currentIndex()]

        crop_box = None
        if (self.crop_x_spin.value() > 0 or self.crop_y_spin.value() > 0 or
                self.crop_w_spin.value() < self.frames[0].width or
                self.crop_h_spin.value() < self.frames[0].height):
            crop_box = (
                self.crop_x_spin.value(),
                self.crop_y_spin.value(),
                self.crop_x_spin.value() + self.crop_w_spin.value(),
                self.crop_y_spin.value() + self.crop_h_spin.value()
            )

        self.worker = GifEditWorker(
            self.gif_path, output_path,
            crop_box=crop_box,
            fps_override=fps_override,
        )
        self.worker.progress.connect(self.on_progress)
        self.worker.finished.connect(self.on_finished)
        self.worker.error.connect(self.on_error)
        
        self.export_btn.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.worker.start()
    
    def on_progress(self, value):
        self.progress_bar.setValue(value)
    
    def on_finished(self, path):
        self.export_btn.setEnabled(True)
        self.progress_bar.setVisible(False)
        QMessageBox.information(self, "Success", f"GIF exported: {Path(path).name}")
    
    def on_error(self, msg):
        self.export_btn.setEnabled(True)
        self.progress_bar.setVisible(False)
        QMessageBox.critical(self, "Error", msg)

# =============================================================================
# Main Window
# =============================================================================

class GifOfDeathApp(QWidget):
    """Main application window."""
    
    def __init__(self):
        super().__init__()
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle(f"{APP_NAME} - {ORG_NAME}")
        self.setGeometry(100, 100, WINDOW_WIDTH, WINDOW_HEIGHT)
        
        # Dark theme
        self.setStyleSheet("""
            QWidget {
                background-color: #0a0a0a;
                color: #fff;
                font-family: Courier;
                font-size: 10pt;
            }
            QTabWidget::pane {
                border: 1px solid #444;
            }
            QTabBar::tab {
                background-color: #1e1e1e;
                color: #bbb;
                padding: 6px 22px;
                border: 1px solid #444;
                border-bottom: none;
                min-width: 100px;
            }
            QTabBar::tab:selected {
                background-color: #3a3a3a;
                color: #fff;
                border-bottom: 2px solid #3a3a3a;
            }
            QTabBar::tab:hover:!selected {
                background-color: #2a2a2a;
                color: #ddd;
            }
            QGroupBox {
                border: 1px solid #333;
                border-radius: 5px;
                margin-top: 10px;
                padding-top: 10px;
                font-weight: bold;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 3px 0 3px;
            }
            QPushButton {
                background-color: #2a2a2a;
                color: #fff;
                border: 1px solid #555;
                padding: 5px;
                border-radius: 3px;
            }
            QPushButton:hover {
                background-color: #3a3a3a;
            }
            QPushButton:pressed {
                background-color: #4a4a4a;
            }
            QSlider::groove:horizontal {
                background-color: #2a2a2a;
                height: 8px;
                border-radius: 4px;
            }
            QSlider::handle:horizontal {
                background-color: #555;
                width: 12px;
                margin: -2px 0;
                border-radius: 6px;
            }
            QSlider::handle:horizontal:hover {
                background-color: #777;
            }
            QProgressBar {
                background-color: #2a2a2a;
                border: 1px solid #555;
                border-radius: 3px;
                text-align: center;
            }
            QProgressBar::chunk {
                background-color: #555;
            }
        """)
        
        # Main layout
        main_layout = QVBoxLayout()
        
        # Tabs
        self.tabs = QTabWidget()
        self.video_tab = VideoToGifTab()
        self.gif_tab = GifEditTab()
        
        self.tabs.addTab(self.video_tab, "Video → GIF")
        self.tabs.addTab(self.gif_tab, "Edit GIF")
        
        main_layout.addWidget(self.tabs)
        self.setLayout(main_layout)

# =============================================================================
# Main Entry Point
# =============================================================================

if __name__ == '__main__':
    # Windows taskbar icon — must be called before QApplication is created
    if sys.platform == 'win32':
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                'DeathsHeadSoftware.GifOfDeath.1'
            )
        except Exception:
            pass

    app = QApplication(sys.argv)

    # Set application icon — covers taskbar, alt-tab, and window chrome
    icon_path = Path(resource_path('icon.ico'))
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    # Create and show splash screen
    splash = create_splash()
    if splash:
        splash.show()
        app.processEvents()
        time.sleep(1)

    # Create main window
    window = GifOfDeathApp()
    window.show()

    if splash:
        splash.finish(window)

    sys.exit(app.exec())
